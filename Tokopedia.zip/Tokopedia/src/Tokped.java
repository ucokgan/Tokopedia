public class Tokped {
    public static void main(String[] args) {

        public String Fotobarang;

        public String Deskripsibarang;

        public String Hargabarang;

        public String Asalbarang;

        private int Status_stok;

        public Tokped(){
        }

        public Tokped(String gb, String db, String hg, String ab,){
            this.Fotobarang = gb;
            this.Deskripsibarang = db;
            this.Hargabarang = hg;
            this.Asalbarang = ab;
            this.Status_stok = 0;

        }

    }
}
