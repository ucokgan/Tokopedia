import java.util.ArrayList;
import java.util.Scanner;

public class Tokopedia {
    public static void main(String[] args) {
        ArrayList<Tokopedia> daftarKartuATM = new ArrayList<Tokopedia>();
        for (int index=0;index<3;index++){
            Tokopedia tokped = new Tokopedia();
            Scanner inputDetail = new Scanner(System.in);
            System.out.println("Masukkan foto Barang");
            tokped.gambar = inputDetail.nextLine();

            System.out.println("Masukkan deskripsi barang");
            tokped.deskripsi = inputDetail.nextLine();

            System.out.println("Masukkan harga barang");
            tokped.harga = inputDetail.nextLine();

            System.out.println("Masukkan asal barang : ");
            tokped.asal = inputDetail.nextLine();

            System.out.println("Masukkan Status stok tersedia : ");
            tokped.status_stok = inputDetail.nextLine();

            daftarentitiTokopedia.add(tokped);
        }

        for(int i=0;i<daftarKartuATM.size();i++){
            String Fotobarang = daftarKartuATM.get(i).gambar;
            String Deskripsibarang = daftarKartuATM.get(i).deskripsi;
            String Hargabarang = daftarKartuATM.get(i).harga;
            String Asalbarang = daftarKartuATM.get(i).asal;
            int Statusstok = daftarentitiTokopedia.get(i).status_stok;
        }

    }
}
